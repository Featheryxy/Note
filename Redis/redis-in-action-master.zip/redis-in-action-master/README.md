redis-in-action

===============

This project intends to hold the various implementations of code from the book Redis in Action,
written by Josiah Carlson, published by Manning Publications, which is available for purchase:
http://manning.com/carlson/

If you would like to read the Errata, it is available as PDF at the above url, or if you would
like to see it as HTML; the most recent version in this repository is (hopefully always) available:
https://htmlpreview.github.io/?https://github.com/josiahcarlson/redis-in-action/blob/master/excerpt_errata.html
