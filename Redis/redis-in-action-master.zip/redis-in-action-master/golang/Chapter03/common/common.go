package common

const (
	OneWeekInSeconds       = 7 * 86400
	VoteScore              = 432
	ArticlesPerPage  int64 = 25
	THIRTYDAYS = 30 * 86400
)


