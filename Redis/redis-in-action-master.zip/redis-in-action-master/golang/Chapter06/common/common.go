package common

const ValidCharacters = "`abcdefghijklmnopqrstuvwxyz{"

var QUIT = false
