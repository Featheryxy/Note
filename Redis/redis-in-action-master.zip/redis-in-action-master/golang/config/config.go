package config

// config for redis
var (
	Addr     = "localhost:6379"
	Password = ""
	DB       = 15
)

// file path for Chapter05 
const FilePath = "../Chapter05/GeoLite2-City-CSV_20200121/"
