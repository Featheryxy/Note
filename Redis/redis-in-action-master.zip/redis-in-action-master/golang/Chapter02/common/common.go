package common

var (
	QUIT        = false
	LIMIT int64 = 10000000
	FLAG  int32 = 1
)
