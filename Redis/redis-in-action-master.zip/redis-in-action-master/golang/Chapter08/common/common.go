package common

const (
	REFILLUSERSSTEP = 50
)

var (
	Postperpass      int64 = 1000
	Hometimelinesize int64 = 1000
)
