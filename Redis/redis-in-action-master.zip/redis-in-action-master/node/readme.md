Redis in Action (the node.js way)
=================================

Chapter 1 completed.

	npm install

To run tests similar to the Python code

	node ch01/test.js

To run mocha based tests covering a little bit more ground.

	node run-mocha-tests.js

Only tested on Mac OS X and node 0.10.x.
