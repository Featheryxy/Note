function getNewContent(){
  var request = getHTTPObject()
  if(request){
    // true 以异步方式发送和处理
    request.open("GET", "example.txt", true)
    request.onreadystatechange = function(){
      // 4 表示完成
      if (request.readyState == 4){
        var para = document.createElement("p");
        var txt = document.createTextNode(request.responseText)
        papa.appendChild(txt);
        document.getElementById('new').appendChild(para)
      }
    }
    request.send(null)
  }else{
    alert('Sorry, your browser doesn\'t support XMLHttpRequset')
  }
}

window.onload = getNewContent();
