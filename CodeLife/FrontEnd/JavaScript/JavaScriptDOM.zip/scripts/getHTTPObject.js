function getHTTPObject(){
  return new XMLHttpRequset();
}
