// window.onload = prepareGallery
// window.onload = firstFunction
// window.onload = secondFunction
// 只执行secondFunction

function addLoadEvent(func){
  var oldonload = window.onload;
  if(typeof window.onload != 'function'){
    window.onload = func;
  }else {
    window.onload = function(){
      oldonload();
      func();
    }
  }
}

function insertAfter(newElement, targetElement){
  var parent = targetElement.parentNode;
  if (parent.lastChild == targetElement){
    parent.appendChild(newElement)
  }else {
    parent.insertBefore(newElement, targetElement.nextSibling)
  }
}

function preparePlaceholder(){
  var placeholder = document.createElement("img")
  placeholder.setAttribute("id", "placeholder")
  placeholder.setAttribute("src", "images/placeholder.jpg")
  var description = document.createElement("p")
  description.setAttribute("id", "description")
  var desctext = document.createTextNode("Choose an image")
  description.appendChild(desctext)

  var gallery = document.getElementById("imagegallery")
  insertAfter(placeholder, gallery)
  insertAfter(description, placeholder)
}

function prepareGallery(){
  if(!document.getElementsByTagName) return false;
  if(!document.getElementById) return false;
  if(!document.getElementById("imagegallery")) return false;
  var gallery = document.getElementById("imagegallery")
  var links = gallery.getElementsByTagName("a")
  for(var i=0; i<links.length; i++){
    links[i].onclick = function(){
      // showPic(this)
      // return false
      // 如果showPic返回true,更新placeholder
      // if(showPic(this)){
      //   return false;
      // }else {
      //   return true
      // }
      return showPic(this)? false:true;
    }
  }
}

function showPic(whichpic){
  // whichpic is element 鼠标点击的元素
  var source = whichpic.getAttribute("href")
  var placeholder = document.getElementById("placeholder")
  placeholder.setAttribute("src", source)

  var text = whichpic.getAttribute("title")
  var description = document.getElementById("description")
  // alert(description.nodeValue)
  // alert(description.childNodes[0].nodeValue)
  // alert(description.firstChild.nodeValue)
  description.firstChild.nodeValue = text

  return true
}

addLoadEvent(preparePlaceholder)
addLoadEvent(prepareGallery)


// 为页面加载完毕时执行的函数创建为一个队列


// document.getElementsByTagName("form")
// function countBodyChildren(){
//   var body_element = document.getElementsByTagName("body")[0]
//   alert(body_element.childNodes.length)
//   alert(body_element.nodeType)
// }

//window.onload = countBodyChildren;

// function popUp(winURL){
// 	window.open(winURL, "popup", "width=320, height=480");
// }

// window.onload = prepareLinks;
// function prepareLinks(){
//   var links = document.getElementsByTagName("a")
//   for (var i=0; i<links.length; i++){
//     if(links[i].getAttribute("class") == "popup"){
//       links[i].onclick = function(){
//         popUp(this.getAttribute("href"))
//         return false
//       }
//     }
//   }
// }
